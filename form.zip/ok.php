
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-v4-rtl/4.6.0-2/css/bootstrap-rtl.min.css">
  <style>
  
  @font-face {
				font-family: 'IranianSansBold';
				src: url('fonts/IranianSansBold.ttf') format('truetype');
				font-weight: normal;
				font-style: normal;
			}

			@font-face {
				font-family: 'IranianSans';
				src: url('fonts/IranianSansRegular.ttf') format('truetype'),
					 url('fonts/IRANSans-web.woff') format('woff');
				font-weight: normal;
				font-style: normal;
			}

			h1,h2,h3,h4,h5,h6,p,span,label,input,.btn,table,select,div,ul,li {
			   font-family: IranianSans !important;
			}
  
  </style>
</head>
<body style="background: #fff;">
	<div style="text-align: center;">
	<img src="ok.gif">
	<h6>درهاست شما جهت انصراف از دریافت پیامک با موفقیت ثبت گردید</h6>
	<h6>همکاران ما در اولین فرصت درخواست شما را بررسی و اقدام خواهند کرد</h6>
	<h6>از شکیبایی شما متشکریم</h6>
	</div>
</body>
</html>